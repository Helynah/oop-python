# Hellen M Wanyana
# CSC-287-01
import adventureGame

adventureGame.print_house_description()

current_location = "garden"

adventureGame.change_location(current_location)
